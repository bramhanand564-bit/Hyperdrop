import { WebSocketServer, WebSocket } from "ws";

const PORT = Number(process.env.PORT || 8080);
const HOST = process.env.HOST || "0.0.0.0";
const wss = new WebSocketServer({ host: HOST, port: PORT });

type Client = WebSocket & { room?: string; role?: "sender" | "receiver" };
const rooms = new Map<string, Set<Client>>();

function send(ws: WebSocket, payload: unknown) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(payload));
}

function validRoom(room: unknown): room is string {
  return typeof room === "string" && /^\d{6}$/.test(room);
}

function removeClient(ws: Client) {
  if (!ws.room) return;
  const set = rooms.get(ws.room);
  set?.delete(ws);
  if (set && set.size === 0) rooms.delete(ws.room);
}

wss.on("connection", (ws: Client) => {
  ws.on("message", raw => {
    try {
      const msg = JSON.parse(raw.toString());

      if (msg.type === "join") {
        if (!validRoom(msg.room) || !["sender", "receiver"].includes(msg.role)) {
          send(ws, { type: "error", message: "Invalid room or role" });
          return;
        }

        removeClient(ws);
        const set = rooms.get(msg.room) || new Set<Client>();

        if (set.size >= 2) {
          send(ws, { type: "error", message: "Room is full" });
          return;
        }

        ws.room = msg.room;
        ws.role = msg.role;
        set.add(ws);
        rooms.set(msg.room, set);

        send(ws, { type: "joined", room: msg.room, role: msg.role, peers: set.size });

        if (set.size === 2) {
          for (const peer of set) send(peer, { type: "peer-ready" });
        }
        return;
      }

      if (msg.type === "signal") {
        if (!ws.room) return;
        const set = rooms.get(ws.room);
        if (!set) return;
        for (const peer of set) {
          if (peer !== ws) send(peer, { type: "signal", data: msg.data });
        }
      }
    } catch {
      send(ws, { type: "error", message: "Invalid message" });
    }
  });

  ws.on("close", () => removeClient(ws));
  ws.on("error", () => removeClient(ws));
});

console.log(`HyperDrop signaling server listening on ws://${HOST}:${PORT}`);
