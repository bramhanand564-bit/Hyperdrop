"use client";

import { useEffect, useMemo, useRef, useState } from "react";

const SIGNAL_URL = process.env.NEXT_PUBLIC_SIGNAL_URL || "ws://localhost:8080";
const CHUNK_SIZE = 64 * 1024;
const BUFFER_LIMIT = 4 * 1024 * 1024;

type SignalMessage =
  | { type: "joined"; room: string; role: "sender" | "receiver"; peers: number }
  | { type: "peer-ready" }
  | { type: "signal"; data: RTCSessionDescriptionInit | RTCIceCandidateInit }
  | { type: "error"; message: string };

function formatBytes(bytes: number) {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB", "PB"];
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / 1024 ** i).toFixed(i ? 2 : 0)} ${units[i]}`;
}

function randomRoom() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function makeIceServers() {
  const servers: RTCIceServer[] = [];
  const stun = process.env.NEXT_PUBLIC_STUN_URL;
  const turn = process.env.NEXT_PUBLIC_TURN_URL;
  if (stun) servers.push({ urls: stun });
  if (turn) {
    servers.push({
      urls: turn,
      username: process.env.NEXT_PUBLIC_TURN_USERNAME,
      credential: process.env.NEXT_PUBLIC_TURN_CREDENTIAL,
    });
  }
  if (!servers.length) servers.push({ urls: "stun:stun.l.google.com:19302" });
  return servers;
}

export default function Home() {
  const [mode, setMode] = useState<"home" | "send" | "receive">("home");
  const [room, setRoom] = useState("");
  const [joinCode, setJoinCode] = useState("");
  const [status, setStatus] = useState("Ready");
  const [file, setFile] = useState<File | null>(null);
  const [progress, setProgress] = useState(0);
  const [transferred, setTransferred] = useState(0);
  const [remoteName, setRemoteName] = useState("");
  const [remoteSize, setRemoteSize] = useState(0);
  const [drag, setDrag] = useState(false);

  const wsRef = useRef<WebSocket | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const dcRef = useRef<RTCDataChannel | null>(null);
  const fileRef = useRef<File | null>(null);
  const receivedRef = useRef<Blob[]>([]);
  const receivedBytesRef = useRef(0);
  const metaRef = useRef<{ name: string; size: number; type: string; hash: string } | null>(null);
  const receiveQueueRef = useRef<ArrayBuffer[]>([]);
  const receivingRef = useRef(false);

  const resetPeer = () => {
    dcRef.current?.close();
    pcRef.current?.close();
    wsRef.current?.close();
    dcRef.current = null;
    pcRef.current = null;
    wsRef.current = null;
    receivedRef.current = [];
    receiveQueueRef.current = [];
    receivedBytesRef.current = 0;
  };

  useEffect(() => () => resetPeer(), []);

  const connectSignal = (code: string, role: "sender" | "receiver") => {
    const ws = new WebSocket(SIGNAL_URL);
    wsRef.current = ws;
    ws.onopen = () => {
      ws.send(JSON.stringify({ type: "join", room: code, role }));
      setStatus("Connected to signaling server");
    };
    ws.onmessage = async (event) => {
      const msg = JSON.parse(event.data) as SignalMessage;
      if (msg.type === "joined") {
        setStatus(msg.role === "sender" ? "Waiting for receiver…" : "Joined room");
        if (msg.role === "receiver" && msg.peers > 1) setupPeer("receiver");
      }
      if (msg.type === "peer-ready") setupPeer(role);
      if (msg.type === "signal") {
        const pc = pcRef.current || setupPeer(role, false);
        if (!pc) return;
        if ("candidate" in msg.data) {
          try { await pc.addIceCandidate(msg.data); } catch {}
        } else if (msg.data.type === "offer") {
          await pc.setRemoteDescription(msg.data);
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          ws.send(JSON.stringify({ type: "signal", data: answer }));
        } else if (msg.data.type === "answer") {
          await pc.setRemoteDescription(msg.data);
        }
      }
      if (msg.type === "error") setStatus(msg.message);
    };
    ws.onerror = () => setStatus("Signaling connection failed");
  };

  const setupPeer = (role: "sender" | "receiver", createChannel = true) => {
    if (pcRef.current) return pcRef.current;
    const pc = new RTCPeerConnection({ iceServers: makeIceServers() });
    pcRef.current = pc;

    pc.onicecandidate = (e) => {
      if (e.candidate && wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: "signal", data: e.candidate.toJSON() }));
      }
    };
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === "connected") setStatus("P2P connection established");
      if (["failed", "disconnected"].includes(pc.connectionState)) setStatus("P2P connection lost");
    };
    pc.ondatachannel = (e) => configureChannel(e.channel);

    if (role === "sender" && createChannel) {
      const dc = pc.createDataChannel("file", { ordered: true });
      configureChannel(dc);
      pc.createOffer().then(async (offer) => {
        await pc.setLocalDescription(offer);
        wsRef.current?.send(JSON.stringify({ type: "signal", data: offer }));
      });
    }
    return pc;
  };

  const configureChannel = (dc: RTCDataChannel) => {
    dcRef.current = dc;
    dc.binaryType = "arraybuffer";
    dc.bufferedAmountLowThreshold = CHUNK_SIZE * 2;
    dc.onopen = () => setStatus("Secure P2P channel ready");
    dc.onclose = () => setStatus("Transfer channel closed");
    dc.onerror = () => setStatus("Data channel error");
    dc.onmessage = async (e) => {
      if (typeof e.data === "string") {
        const message = JSON.parse(e.data);
        if (message.type === "meta") {
          metaRef.current = message;
          setRemoteName(message.name);
          setRemoteSize(message.size);
          setTransferred(0);
          setProgress(0);
          receivedRef.current = [];
          receivedBytesRef.current = 0;
          receivingRef.current = true;
          setStatus("Receiving file…");
        }
        if (message.type === "done") {
          const meta = metaRef.current;
          const blob = new Blob(receivedRef.current, { type: meta?.type || "application/octet-stream" });
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = meta?.name || "download";
          a.click();
          setTimeout(() => URL.revokeObjectURL(url), 10000);
          receivingRef.current = false;
          setProgress(100);
          setTransferred(blob.size);
          setStatus("Transfer complete — file downloaded");
        }
        return;
      }
      const buf = e.data as ArrayBuffer;
      receiveQueueRef.current.push(buf);
      receivedRef.current.push(new Blob([buf]));
      receivedBytesRef.current += buf.byteLength;
      const size = metaRef.current?.size || 1;
      setTransferred(receivedBytesRef.current);
      setProgress(Math.min(100, (receivedBytesRef.current / size) * 100));
    };
  };

  const sha256 = async (f: File) => {
    const data = await f.arrayBuffer();
    const digest = await crypto.subtle.digest("SHA-256", data);
    return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, "0")).join("");
  };

  const sendFile = async () => {
    const f = fileRef.current;
    const dc = dcRef.current;
    if (!f || !dc || dc.readyState !== "open") return;
    setStatus("Preparing file hash…");
    const hash = await sha256(f);
    dc.send(JSON.stringify({ type: "meta", name: f.name, size: f.size, type: f.type, hash }));
    let offset = 0;
    setTransferred(0);
    setProgress(0);
    setStatus("Sending…");

    while (offset < f.size) {
      if (dc.readyState !== "open") throw new Error("Connection closed");
      if (dc.bufferedAmount > BUFFER_LIMIT) {
        await new Promise<void>(resolve => {
          const timer = window.setInterval(() => {
            if (dc.bufferedAmount <= CHUNK_SIZE * 2) {
              window.clearInterval(timer);
              resolve();
            }
          }, 25);
        });
      }
      const chunk = await f.slice(offset, offset + CHUNK_SIZE).arrayBuffer();
      dc.send(chunk);
      offset += chunk.byteLength;
      setTransferred(offset);
      setProgress((offset / f.size) * 100);
      await new Promise(requestAnimationFrame);
    }
    dc.send(JSON.stringify({ type: "done" }));
    setProgress(100);
    setStatus("Transfer complete");
  };

  const chooseFile = (f: File | undefined) => {
    if (!f) return;
    fileRef.current = f;
    setFile(f);
    setTransferred(0);
    setProgress(0);
    setStatus("File selected — connect a receiver");
  };

  const createRoom = () => {
    resetPeer();
    const code = randomRoom();
    setRoom(code);
    setMode("send");
    setStatus("Connecting…");
    connectSignal(code, "sender");
  };

  const joinRoom = () => {
    if (!/^\d{6}$/.test(joinCode)) {
      setStatus("Enter a 6-digit code");
      return;
    }
    resetPeer();
    setRoom(joinCode);
    setMode("receive");
    setStatus("Connecting…");
    connectSignal(joinCode, "receiver");
  };

  const copyRoom = async () => {
    await navigator.clipboard.writeText(room);
    setStatus("Room code copied");
  };

  const percent = useMemo(() => Math.round(progress), [progress]);

  if (mode === "home") {
    return (
      <main className="container">
        <section className="hero">
          <div className="logo">Hyper<span>Drop</span></div>
          <p className="muted">Fast, private, peer-to-peer file transfer over the Internet.</p>
        </section>
        <section className="grid">
          <div className="card panel">
            <h2>Send files</h2>
            <p className="muted">Create a temporary room and share its code with the receiver.</p>
            <button className="primary" onClick={createRoom}>Create transfer room</button>
          </div>
          <div className="card panel">
            <h2>Receive files</h2>
            <p className="muted">Enter the sender&apos;s 6-digit room code.</p>
            <div className="row">
              <input inputMode="numeric" maxLength={6} placeholder="123456" value={joinCode} onChange={e => setJoinCode(e.target.value.replace(/\D/g, ""))} />
              <button className="primary" onClick={joinRoom}>Join</button>
            </div>
          </div>
        </section>
        <div className="notice">
          Files normally travel directly between the two browsers through WebRTC. The signaling server only helps them find each other.
        </div>
        <div className="footer">HyperDrop • P2P transfer starter</div>
      </main>
    );
  }

  return (
    <main className="container">
      <section className="hero">
        <div className="logo">Hyper<span>Drop</span></div>
        <p className="muted">{mode === "send" ? "Send a file" : "Receive a file"}</p>
      </section>

      <section className="card panel">
        <div className="stat"><span className="muted">Room</span><strong>{room}</strong></div>
        <div className="code">{room}</div>
        <div className="row" style={{ marginTop: 12 }}>
          <button className="secondary" onClick={copyRoom}>Copy code</button>
          <button className="secondary" onClick={() => { resetPeer(); setMode("home"); }}>Leave</button>
        </div>

        {mode === "send" ? (
          <>
            <div
              className={`drop ${drag ? "drag" : ""}`}
              onDragOver={e => { e.preventDefault(); setDrag(true); }}
              onDragLeave={() => setDrag(false)}
              onDrop={e => { e.preventDefault(); setDrag(false); chooseFile(e.dataTransfer.files?.[0]); }}
            >
              <p><strong>{file ? file.name : "Drop a file here"}</strong></p>
              <p className="muted">{file ? formatBytes(file.size) : "or choose a file from your device"}</p>
              <input type="file" onChange={e => chooseFile(e.target.files?.[0])} />
            </div>
            <div className="row" style={{ marginTop: 18 }}>
              <button className="primary" disabled={!file || status !== "Secure P2P channel ready"} onClick={sendFile}>
                Send file
              </button>
            </div>
          </>
        ) : (
          <div className="notice">
            {remoteName ? <><strong>{remoteName}</strong> • {formatBytes(remoteSize)}</> : "Waiting for the sender to start…"}
          </div>
        )}

        <div style={{ marginTop: 24 }}>
          <div className="stat"><span>{status}</span><strong>{percent}%</strong></div>
          <div className="progress"><div className="bar" style={{ width: `${progress}%` }} /></div>
          <div className="stat"><span className="muted">Transferred</span><span>{formatBytes(transferred)}{remoteSize ? ` / ${formatBytes(remoteSize)}` : file ? ` / ${formatBytes(file.size)}` : ""}</span></div>
        </div>
      </section>

      <div className="notice">
        <strong>Internet note:</strong> for networks that block direct WebRTC connections, configure a TURN server in the environment variables. TURN relays traffic but is only a fallback.
      </div>
      <div className="footer">HyperDrop • P2P transfer starter</div>
    </main>
  );
}
