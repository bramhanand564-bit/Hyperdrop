import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "HyperDrop",
  description: "Fast peer-to-peer file transfer over the Internet",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
