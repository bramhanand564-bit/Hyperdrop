# HyperDrop Roadmap

## Included in this starter
- Web UI
- 6-digit room pairing
- WebSocket signaling
- WebRTC DataChannel
- Chunked file streaming
- Backpressure
- SHA-256 metadata generation
- STUN/TURN environment configuration
- Docker files

## Next production milestones
1. TURN deployment (coturn) with short-lived credentials.
2. Authenticated room tokens instead of only numeric room codes.
3. End-to-end encrypted application protocol with per-transfer keys.
4. True resumable transfers using chunk indexes + persistent receiver state.
5. File/folder selection and multi-file manifests.
6. Progress ETA, transfer speed, retry telemetry.
7. Redis-backed signaling for multiple server instances.
8. PostgreSQL for optional transfer/session metadata.
9. Rate limiting, abuse controls, room expiration and connection quotas.
10. Native desktop/mobile clients for background transfers.
11. Optional encrypted relay/object-storage fallback for peers that cannot establish P2P.
12. Automated tests and observability.
